# Generated code
def add_arguments(pars):
    pars.add_argument("--page", type=str)
    pars.add_argument("--target", type=str, default="")
    pars.add_argument("--start", type=float, default=0.0)
    pars.add_argument("--depth", type=float, default=10.0)
    pars.add_argument("--ergo_side", type=str, default="b")
    pars.add_argument("--angle", type=float, default=25.0)
    pars.add_argument("--fret", type=int, default=1)

